import "./App.css";
import CardForm from "./Components/CardForm";
import "bootstrap/dist/css/bootstrap.min.css";

function App() {
  return (
    <div className="App">
      <CardForm />
    </div>
  );
}

export default App;
